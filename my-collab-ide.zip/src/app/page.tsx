'use client';

import Home from '@/app/home/page';

export default function HomePage() {
  return <Home />;
}
