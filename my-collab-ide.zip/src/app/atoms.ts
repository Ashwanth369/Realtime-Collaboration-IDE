import { atom } from 'jotai';

export const language = atom<string>("javascript");

export const cmtheme = atom<string>("monokai");
